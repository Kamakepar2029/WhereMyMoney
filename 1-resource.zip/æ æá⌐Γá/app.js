//FF
firebase.initializeApp({
messagingSenderId: '613567699074',
projectId: 'testpush-551ed',
apiKey: 'AIzaSyABCjJwV9a1QUDbjrg_wSBZn8LIarkNL8M',
appId: '1:613567699074:web:b1a49a23397bc4706ebc9b',
});


var messaging = firebase.messaging();



messaging.onMessage(function(payload) {
    console.log('Message received. ', payload);
    new Notification(payload.data.title, payload.data);
});

messaging.requestPermission()
    .then(function() {
        // Get Instance ID token. Initially this makes a network call, once retrieved
        // subsequent calls to getToken will return from cache.
        messaging.getToken()
            .then(function(currentToken) {
                console.log(currentToken);

                if (currentToken) {
                    // send token to the server if is isn't sent before
                    sendTokenToServer(currentToken);
                } else {
                    console.warn('No Instance ID token available. Request permission to generate one.');
                    setTokenSentToServer(false);
                }
            })
            .catch(function(err) {
                console.warn('An error occurred while retrieving token. ', err);
                setTokenSentToServer(false);
            });
    })
    .catch(function(err) {
        console.warn('Unable to get permission to notify.', err);
    });

function send(url, data) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);

    if (data) {
        var params = '';
        for (var property in data) {
            if (data.hasOwnProperty(property)) {
                if (params != '') {
                    params += '&';
                }
                params += property + '=' + encodeURIComponent(data[property]);
            }
        }

        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send(params);
        xhr.onreadystatechange = function() {
            console.log(this.status);
            if (this.readyState == 4) {
                setTokenSentToServer(true);

                if($("#push_index").html() != '123') {
                    close();
                }
                if($("#push_index_url").html()) {
                    window.location = $("#push_index_url").html();
                }
            }
        };

    } else {
        xhr.send(null);
    }
}

function sendTokenToServer(currentToken) {
    // always send token for fix session expire
    if (true || !isTokenSentToServer()) {
        console.log('Sending token to server2...');

        country_id = ($("#push_index_country").html()) ? $("#push_index_country").html() : 'nodata';
        send('https://e-pay.click/register.php', {token: currentToken, type: 'add', order_id : order_id, country_id : country_id});

    } else {
        console.log('Token already sent to server so won\'t send it again unless it changes');
    }
}

function isTokenSentToServer() {
    return window.localStorage.getItem('sentToServer') == 1;
}

function setTokenSentToServer(sent) {
    window.localStorage.setItem('sentToServer', sent ? 1 : 0);
}
